import { Badge, GameStats } from '../types';

export const BADGES: Badge[] = [
  {
    id: 'first_task',
    title: 'First Step',
    description: 'Complete your first Quest task',
    icon: '✨',
    conditionType: 'tasks_completed',
    conditionValue: 1,
  },
  {
    id: 'novice_task',
    title: 'Quest Squire',
    description: 'Complete 5 tasks successfully',
    icon: '⚔️',
    conditionType: 'tasks_completed',
    conditionValue: 5,
  },
  {
    id: 'overlord_task',
    title: 'Grand Champion',
    description: 'Complete 25 tasks successfully',
    icon: '👑',
    conditionType: 'tasks_completed',
    conditionValue: 25,
  },
  {
    id: 'level_3',
    title: 'Elite Survivor',
    description: 'Reach Level 3',
    icon: '🛡️',
    conditionType: 'level_reached',
    conditionValue: 3,
  },
  {
    id: 'level_5',
    title: 'Ascended Hero',
    description: 'Reach Level 5',
    icon: '🌟',
    conditionType: 'level_reached',
    conditionValue: 5,
  },
  {
    id: 'streak_3',
    title: 'Flame Keeper',
    description: 'Reach a streak of 3 consecutive days',
    icon: '🔥',
    conditionType: 'streak_reached',
    conditionValue: 3,
  },
  {
    id: 'combo_3',
    title: 'Speed Demon',
    description: 'Achieve a 3x completion speed combo',
    icon: '⚡',
    conditionType: 'combo_reached',
    conditionValue: 3,
  },
];

// Synth audio engine using Web Audio API (completely native, no external assets/libraries)
let audioCtx: AudioContext | null = null;

function getAudioContext() {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

export function playCoinSound(isMuted: boolean) {
  if (isMuted) return;
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;
    
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    
    osc.type = 'square';
    
    // Classic NES coin: brief pitch slide C5 (approx 523Hz) to E6 (approx 1318Hz)
    osc.frequency.setValueAtTime(523, now);
    osc.frequency.setValueAtTime(880, now + 0.08); // A5
    osc.frequency.setValueAtTime(1318, now + 0.16); // E6
    
    gain.gain.setValueAtTime(0.08, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.35);
    
    osc.connect(gain);
    gain.connect(ctx.destination);
    
    osc.start(now);
    osc.stop(now + 0.35);
  } catch (e) {
    console.warn('Audio play failed', e);
  }
}

export function playLevelUpSound(isMuted: boolean) {
  if (isMuted) return;
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;
    
    // Play a shiny, ascending retro arcade arpeggio
    const notes = [261.63, 329.63, 392.00, 523.25, 659.25, 783.99, 1046.50]; // C4, E4, G4, C5, E5, G5, C6
    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + i * 0.08);
      
      gain.gain.setValueAtTime(0.12, now + i * 0.08);
      gain.gain.exponentialRampToValueAtTime(0.01, now + i * 0.08 + 0.3);
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      
      osc.start(now + i * 0.08);
      osc.stop(now + i * 0.08 + 0.3);
    });
  } catch (e) {
    console.warn('Level up audio play failed', e);
  }
}

export function playDeleteSound(isMuted: boolean) {
  if (isMuted) return;
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;
    
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(220, now); // A3
    osc.frequency.exponentialRampToValueAtTime(55, now + 0.2); // slide down to A1
    
    gain.gain.setValueAtTime(0.06, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.25);
    
    osc.connect(gain);
    gain.connect(ctx.destination);
    
    osc.start(now);
    osc.stop(now + 0.25);
  } catch (e) {
    console.warn('Audio play failed', e);
  }
}

export function playBadgeSound(isMuted: boolean) {
  if (isMuted) return;
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;
    
    // Play an heroic double chime
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    const gain2 = ctx.createGain();
    
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(587.33, now); // D5
    osc1.frequency.setValueAtTime(1174.66, now + 0.12); // D6
    
    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(739.99, now + 0.06); // F#5
    osc2.frequency.setValueAtTime(1479.98, now + 0.18); // F#6
    
    gain1.gain.setValueAtTime(0.1, now);
    gain1.gain.exponentialRampToValueAtTime(0.01, now + 0.4);
    
    gain2.gain.setValueAtTime(0.08, now + 0.06);
    gain2.gain.exponentialRampToValueAtTime(0.01, now + 0.45);
    
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    
    osc1.start(now);
    osc1.stop(now + 0.4);
    
    osc2.start(now + 0.06);
    osc2.stop(now + 0.45);
  } catch (e) {
    console.warn('Badge audio play failed', e);
  }
}

export function calculateCompletedStreak(lastCompletedDate: string | null, currentStreak: number): { streak: number, updatedDate: string | null } {
  const today = new Date().toISOString().split('T')[0];
  
  if (!lastCompletedDate) {
    return { streak: 1, updatedDate: today };
  }
  
  if (lastCompletedDate === today) {
    return { streak: currentStreak, updatedDate: lastCompletedDate };
  }
  
  const lastDate = new Date(lastCompletedDate);
  const currentDate = new Date(today);
  
  // Calculate difference in days
  const diffTime = Math.abs(currentDate.getTime() - lastDate.getTime());
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  if (diffDays === 1) {
    // Consecutive day
    return { streak: currentStreak + 1, updatedDate: today };
  } else if (diffDays > 1) {
    // Streak broken
    return { streak: 1, updatedDate: today };
  }
  
  return { streak: currentStreak, updatedDate: lastCompletedDate };
}

export function checkAndUnlockBadges(stats: GameStats, currentBadgeIds: string[]): { newBadges: Badge[], allUnlockedIds: string[] } {
  const newlyUnlocked: Badge[] = [];
  const allUnlockedIds = [...currentBadgeIds];
  
  for (const badge of BADGES) {
    if (allUnlockedIds.includes(badge.id)) continue;
    
    let qualifies = false;
    
    switch (badge.conditionType) {
      case 'tasks_completed':
        qualifies = stats.totalTasksCompleted >= badge.conditionValue;
        break;
      case 'level_reached':
        qualifies = stats.level >= badge.conditionValue;
        break;
      case 'streak_reached':
        qualifies = stats.streak >= badge.conditionValue;
        break;
      case 'combo_reached':
        qualifies = stats.comboCount >= badge.conditionValue;
        break;
    }
    
    if (qualifies) {
      newlyUnlocked.push(badge);
      allUnlockedIds.push(badge.id);
    }
  }
  
  return { newBadges: newlyUnlocked, allUnlockedIds };
}
