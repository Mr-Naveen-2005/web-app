import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Task, GameStats, Badge } from './types';
import {
  BADGES,
  playCoinSound,
  playLevelUpSound,
  playDeleteSound,
  playBadgeSound,
  calculateCompletedStreak,
  checkAndUnlockBadges,
} from './utils/gameHelpers';

// Helper to determine rank name based on level
function getRankName(level: number): string {
  if (level < 2) return 'Abyssal Novice';
  if (level < 5) return 'Shadow Recruit';
  if (level < 10) return 'Dungeon Raider';
  if (level < 15) return 'Arcane Warden';
  if (level < 25) return 'Quest Champion';
  return 'Legendary Immortal';
}

const COMBO_WINDOW_MS = 45000; // 45 seconds to chain combos

export default function App() {
  // --- Game Persistence State ---
  const [tasks, setTasks] = useState<Task[]>(() => {
    try {
      const saved = localStorage.getItem('quest_tasks');
      return saved ? JSON.parse(saved) : [
        {
          id: 'preset1',
          text: 'Defeat the Morning Sloth (Wake up before 8:00 AM)',
          difficulty: 'medium',
          completed: false,
          createdAt: new Date().toISOString(),
          completedAt: null,
          category: 'daily',
        },
        {
          id: 'preset2',
          text: 'Perform Code Rituals (Solve 1 algorithms quest)',
          difficulty: 'hard',
          completed: false,
          createdAt: new Date().toISOString(),
          completedAt: null,
          category: 'quest',
        },
        {
          id: 'preset3',
          text: 'Hydrate like an Ocean Boss (Drink 3L of water)',
          difficulty: 'easy',
          completed: true,
          createdAt: new Date().toISOString(),
          completedAt: new Date().toISOString(),
          category: 'daily',
        }
      ];
    } catch {
      return [];
    }
  });

  const [stats, setStats] = useState<GameStats>(() => {
    try {
      const saved = localStorage.getItem('quest_stats');
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      xp: 10, // start with small base
      level: 1,
      streak: 0,
      lastCompletedDate: null,
      comboCount: 1,
      lastCompletedTime: null,
      totalTasksCompleted: 1,
      unlockedBadgeIds: [],
    };
  });

  const [isMuted, setIsMuted] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('quest_mute');
      return saved ? JSON.parse(saved) : false;
    } catch {
      return false;
    }
  });

  // --- UI Filter & Creation State ---
  const [activeFilter, setActiveFilter] = useState<'all' | 'quest' | 'daily' | 'boss' | 'completed'>('all');
  const [inputText, setInputText] = useState('');
  const [inputCategory, setInputCategory] = useState<'quest' | 'daily' | 'boss'>('quest');
  const [inputDifficulty, setInputDifficulty] = useState<'easy' | 'medium' | 'hard'>('easy');

  // --- Animation/Visual States ---
  const [showLevelUp, setShowLevelUp] = useState(false);
  const [levelUpFrom, setLevelUpFrom] = useState(1);
  const [recentlyUnlockedBadges, setRecentlyUnlockedBadges] = useState<Badge[]>([]);
  const [comboTimeLeftFraction, setComboTimeLeftFraction] = useState(1); // 1.0 down to 0.0
  const [xpAddedToast, setXpAddedToast] = useState<{ xp: number; multiplier: number; id: number } | null>(null);

  // Reference for tracking previous total completion counts to avoid double checking
  const prevCompletionsRef = useRef(stats.totalTasksCompleted);

  // Save Tasks to LocalStorage
  useEffect(() => {
    localStorage.setItem('quest_tasks', JSON.stringify(tasks));
  }, [tasks]);

  // Save Stats to LocalStorage
  useEffect(() => {
    localStorage.setItem('quest_stats', JSON.stringify(stats));
  }, [stats]);

  // Save Mute state to LocalStorage
  useEffect(() => {
    localStorage.setItem('quest_mute', JSON.stringify(isMuted));
  }, [isMuted]);

  // Handle active combo cooldown timer tick
  useEffect(() => {
    if (!stats.lastCompletedTime || stats.comboCount <= 1) {
      setComboTimeLeftFraction(0);
      return;
    }

    const interval = setInterval(() => {
      const elapsed = Date.now() - (stats.lastCompletedTime || 0);
      const remainingFraction = Math.max(0, (COMBO_WINDOW_MS - elapsed) / COMBO_WINDOW_MS);
      
      setComboTimeLeftFraction(remainingFraction);

      if (elapsed >= COMBO_WINDOW_MS) {
        // Combo decayed completely - reset combo to 1
        setStats(prev => ({
          ...prev,
          comboCount: 1,
          lastCompletedTime: null,
        }));
        clearInterval(interval);
      }
    }, 100);

    return () => clearInterval(interval);
  }, [stats.lastCompletedTime, stats.comboCount]);

  // Task creation handler
  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const newTask: Task = {
      id: `task_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
      text: inputText.trim(),
      difficulty: inputDifficulty,
      completed: false,
      createdAt: new Date().toISOString(),
      completedAt: null,
      category: inputCategory,
    };

    setTasks(prev => [newTask, ...prev]);
    setInputText('');
    
    // Play sound click
    playCoinSound(isMuted);
  };

  // Toggle completion handler
  const handleToggleTask = (taskId: string) => {
    const updatedTasks = tasks.map(task => {
      if (task.id === taskId) {
        const newlyCompleted = !task.completed;
        return {
          ...task,
          completed: newlyCompleted,
          completedAt: newlyCompleted ? new Date().toISOString() : null,
        };
      }
      return task;
    });

    const targetTask = tasks.find(t => t.id === taskId);
    if (!targetTask) return;

    const isCompleting = !targetTask.completed;
    setTasks(updatedTasks);

    if (isCompleting) {
      // Award XP based on difficulty
      let baseXP = 10;
      if (targetTask.difficulty === 'medium') baseXP = 20;
      if (targetTask.difficulty === 'hard') baseXP = 40;

      // Handle combo system
      const nowMs = Date.now();
      let newComboCount = 1;
      let multiplier = 1.0;

      if (stats.lastCompletedTime) {
        const timeDiff = nowMs - stats.lastCompletedTime;
        if (timeDiff <= COMBO_WINDOW_MS) {
          newComboCount = stats.comboCount + 1;
          if (newComboCount === 2) multiplier = 1.25;
          else if (newComboCount === 3) multiplier = 1.5;
          else if (newComboCount >= 4) multiplier = 2.0;
        }
      }

      const xpEarned = Math.round(baseXP * multiplier);
      const newTotalXP = stats.xp + xpEarned;
      const newLevel = Math.floor(newTotalXP / 100) + 1;
      const oldLevel = stats.level;

      // Update streaks
      const streakResult = calculateCompletedStreak(stats.lastCompletedDate, stats.streak);

      // Assemble updated stats
      const nextStats: GameStats = {
        ...stats,
        xp: newTotalXP,
        level: newLevel,
        streak: streakResult.streak,
        lastCompletedDate: streakResult.updatedDate,
        comboCount: newComboCount,
        lastCompletedTime: nowMs,
        totalTasksCompleted: stats.totalTasksCompleted + 1,
        unlockedBadgeIds: stats.unlockedBadgeIds,
      };

      // Sound trigger
      if (newLevel > oldLevel) {
        setLevelUpFrom(oldLevel);
        setShowLevelUp(true);
        playLevelUpSound(isMuted);
      } else {
        playCoinSound(isMuted);
      }

      // Render Floating Toast XP
      setXpAddedToast({ xp: xpEarned, multiplier, id: Date.now() });

      // Check badges
      const badgeCheck = checkAndUnlockBadges(nextStats, stats.unlockedBadgeIds);
      if (badgeCheck.newBadges.length > 0) {
        setRecentlyUnlockedBadges(prev => [...prev, ...badgeCheck.newBadges]);
        playBadgeSound(isMuted);
        nextStats.unlockedBadgeIds = badgeCheck.allUnlockedIds;
      }

      setStats(nextStats);
    } else {
      // Toggle off completed - subtract standard xp corresponding to difficulty (base simple 10-30 xp)
      let baseXP = 10;
      if (targetTask.difficulty === 'medium') baseXP = 20;
      if (targetTask.difficulty === 'hard') baseXP = 40;

      const newXP = Math.max(0, stats.xp - baseXP);
      const newLevel = Math.max(1, Math.floor(newXP / 100) + 1);

      setStats(prev => ({
        ...prev,
        xp: newXP,
        level: newLevel,
        totalTasksCompleted: Math.max(0, prev.totalTasksCompleted - 1),
      }));

      playDeleteSound(isMuted);
    }
  };

  // Delete Task handler
  const handleDeleteTask = (taskId: string) => {
    setTasks(prev => prev.filter(t => t.id !== taskId));
    playDeleteSound(isMuted);
  };

  // Skip Quest/Simulate day for testing streak system (developer Easter egg)
  const handleSimulateStreakDay = () => {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split('T')[0];

    setStats(prev => ({
      ...prev,
      lastCompletedDate: yesterdayStr,
      streak: prev.streak === 0 ? 1 : prev.streak,
    }));
    playCoinSound(isMuted);
  };

  // Reset entire Profile
  const handleResetAdventure = () => {
    if (window.confirm('⚠️ ARE YOU SURE? THIS WILL EXTERMINATE YOUR COMPLETE RPG PROFILE, STATS, LEVELS, AND QUEST LOG!')) {
      setTasks([]);
      setStats({
        xp: 0,
        level: 1,
        streak: 0,
        lastCompletedDate: null,
        comboCount: 1,
        lastCompletedTime: null,
        totalTasksCompleted: 0,
        unlockedBadgeIds: [],
      });
      playDeleteSound(isMuted);
    }
  };

  const currentLevelProgressXP = stats.xp % 100;
  const currentRank = getRankName(stats.level);

  // Filter conditions
  const filteredTasks = tasks.filter(task => {
    if (activeFilter === 'completed') return task.completed;
    if (task.completed) return false; // Non-completed screen by default for non-completed filters
    if (activeFilter === 'all') return true;
    return task.category === activeFilter;
  });

  const getDifficultyColor = (diff: 'easy' | 'medium' | 'hard') => {
    switch (diff) {
      case 'easy': return 'text-emerald-400 bg-emerald-950/40 border-emerald-800/50';
      case 'medium': return 'text-amber-400 bg-amber-950/40 border-amber-800/50';
      case 'hard': return 'text-rose-400 bg-rose-950/40 border-rose-800/50';
    }
  };

  const getCategoryEmoji = (category: 'quest' | 'daily' | 'boss') => {
    switch (category) {
      case 'quest': return '🛡️';
      case 'daily': return '📅';
      case 'boss': return '💀';
    }
  };

  return (
    <div id="game_container" className="relative min-h-screen bg-slate-950 overflow-hidden font-sans pb-16 selection:bg-purple-600">
      
      {/* Dynamic Cyber Retro Grid background */}
      <div className="absolute inset-0 z-0 pointer-events-none opacity-25 overflow-hidden">
        <div 
          className="w-[200%] h-[200%] absolute top-[-50%] left-[-50%] bg-[linear-gradient(rgba(147,51,234,0.06)_1px,transparent_1px),linear-gradient(90deg,rgba(147,51,234,0.06)_1px,transparent_1px)] bg-[size:40px_40px] animate-retro-grid"
          style={{ transform: 'perspective(500px) rotateX(60deg)' }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-slate-950" />
      </div>

      {/* Retro scanlines overlay */}
      <div className="crt-overlay relative z-10 flex flex-col items-center">
        
        {/* HEADER SECTION */}
        <header id="main_header" className="w-full max-w-5xl px-4 sm:px-6 pt-6 pb-2 border-b border-purple-900/30 flex items-center justify-between z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-tr from-purple-600 to-cyan-400 flex items-center justify-center font-bold text-xl text-slate-950 shadow-[0_0_15px_rgba(168,85,247,0.5)]">
              🕹️
            </div>
            <div>
              <h1 className="font-orbitron font-black text-xl sm:text-2xl tracking-wider text-glow-purple bg-gradient-to-r from-purple-400 to-cyan-300 bg-clip-text text-transparent">
                QUEST_LOGGER v1.0
              </h1>
              <p className="font-mono text-[9px] uppercase tracking-widest text-purple-400/80">
                Turn your grind into glory
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            <button
              id="mute_btn"
              onClick={() => setIsMuted(prev => !prev)}
              className={`p-2 rounded-md border flex items-center justify-center transition ${
                isMuted 
                  ? 'border-rose-900/40 bg-rose-950/20 text-rose-400 hover:bg-rose-950/40' 
                  : 'border-cyan-900/40 bg-cyan-950/20 text-cyan-400 hover:bg-cyan-950/40'
              }`}
              title={isMuted ? "Unmute Sounds" : "Mute Sounds"}
            >
              {isMuted ? '🔇' : '🔊'}
            </button>
            <button
              id="reset_btn"
              onClick={handleResetAdventure}
              className="px-3 py-1.5 rounded-md border border-slate-800 bg-slate-900/60 text-slate-400 font-mono text-xs hover:text-rose-400 hover:border-rose-950 hover:bg-rose-950/30 transition cursor-pointer"
              title="Wipe current quest progress"
            >
              RESET_ADV
            </button>
          </div>
        </header>

        {/* STATS HERO GRID DASHBOARD */}
        <section id="stats_dashboard" className="w-full max-w-5xl px-4 sm:px-6 mt-6 grid grid-cols-1 md:grid-cols-4 gap-4 z-10">
          
          {/* LEVEL CARD */}
          <div id="stat_level" className="bg-slate-900/60 border border-purple-900/40 rounded-xl p-4 flex flex-col justify-between glow-purple relative group hover:border-purple-500/30 transition duration-300">
            <div className="absolute top-2 right-3 text-2xl">🥇</div>
            <div>
              <span className="font-mono text-xs text-purple-400 uppercase tracking-widest block">Level Sector</span>
              <span className="font-orbitron text-4xl font-extrabold text-glow-purple text-purple-300">
                {stats.level}
                <span className="text-xs font-sans text-cyan-400 ml-2 font-medium bg-cyan-950/50 px-2 py-0.5 rounded-full border border-cyan-900/50">
                  {currentRank}
                </span>
              </span>
            </div>
            <div className="mt-4">
              <div className="flex justify-between font-mono text-[10px] text-purple-400/80 mb-1">
                <span>XP PROGRESS</span>
                <span>{currentLevelProgressXP} / 100 XP</span>
              </div>
              <div className="w-full h-3 bg-purple-950/50 rounded-full overflow-hidden border border-purple-900/60 p-[1px]">
                <motion.div 
                  id="xp_filling_bar"
                  className="h-full bg-gradient-to-r from-purple-500 to-cyan-400 rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${currentLevelProgressXP}%` }}
                  transition={{ type: 'spring', damping: 15 }}
                />
              </div>
            </div>
          </div>

          {/* TOTAL XP CARD */}
          <div id="stat_xp" className="bg-slate-900/60 border border-cyan-900/40 rounded-xl p-4 flex flex-col justify-between glow-cyan hover:border-cyan-500/30 transition duration-300 relative">
            <div className="absolute top-2 right-3 text-2xl">🎖️</div>
            <div>
              <span className="font-mono text-xs text-cyan-400 uppercase tracking-widest block">Total Power Log</span>
              <span className="font-orbitron text-4xl font-extrabold text-glow-cyan text-cyan-300">
                {stats.xp} <span className="text-sm font-sans font-light text-cyan-500">XP</span>
              </span>
            </div>
            <p className="text-[11px] font-mono text-slate-400 mt-4 leading-relaxed">
              Earned primarily through complete task logs and active streak multipliers.
            </p>
          </div>

          {/* STREAK CARD */}
          <div id="stat_streak" className="bg-slate-900/60 border border-purple-900/40 rounded-xl p-4 flex flex-col justify-between glow-purple hover:border-purple-500/30 transition duration-300 relative">
            <div className="absolute top-2 right-3 text-2xl">🔥</div>
            <div>
              <span className="font-mono text-xs text-purple-400 uppercase tracking-widest block">Flame Streak</span>
              <span className="font-orbitron text-4xl font-extrabold text-glow-purple text-purple-300">
                {stats.streak} <span className="text-sm font-sans font-normal text-purple-400">{stats.streak === 1 ? 'DAY' : 'DAYS'}</span>
              </span>
            </div>
            <div className="mt-4 flex flex-col gap-1">
              <span className="text-[10px] font-mono text-purple-200/60 uppercase">
                {stats.streak > 0 ? 'KEEP THE FLAME ALIVE!' : 'NO ACTIVE STREAK'}
              </span>
              <div className="flex gap-2">
                <button
                  onClick={handleSimulateStreakDay}
                  className="text-[9px] font-mono text-purple-400 hover:text-cyan-300 bg-purple-950/40 px-2 py-0.5 rounded border border-purple-900/40 hover:border-cyan-900 transition mt-1 cursor-pointer"
                  title="Simulates standard 1-day step into yesterday for debugging streak counters consecutively"
                >
                  ⚡ DEV: STREAK SKP (-1 Day)
                </button>
              </div>
            </div>
          </div>

          {/* COMBO BONUS CARD */}
          <div id="stat_combo" className="bg-slate-900/60 border border-cyan-900/40 rounded-xl p-4 flex flex-col justify-between glow-cyan hover:border-cyan-500/30 transition duration-300 relative">
            <div className="absolute top-2 right-3 text-2xl">⚡</div>
            <div>
              <span className="font-mono text-xs text-cyan-400 uppercase tracking-widest block">Combo Multiplier</span>
              <div className="flex items-baseline gap-2">
                <span className={`font-orbitron text-4xl font-black ${
                  stats.comboCount > 1 ? 'text-glow-cyan text-cyan-300 animate-pulse' : 'text-slate-500'
                }`}>
                  x{stats.comboCount === 2 ? '1.25' : stats.comboCount === 3 ? '1.5' : stats.comboCount >= 4 ? '2.0' : '1.0'}
                </span>
                {stats.comboCount > 1 && (
                  <span className="font-mono text-[10px] bg-cyan-950/80 px-1.5 py-0.5 rounded text-cyan-400 border border-cyan-900/40">
                    COMBO {stats.comboCount}!
                  </span>
                )}
              </div>
            </div>
            <div className="mt-4">
              <div className="flex justify-between font-mono text-[10px] text-cyan-400/80 mb-1">
                <span>COMBO COOLDOWN</span>
                <span>{stats.comboCount > 1 ? `${Math.round(comboTimeLeftFraction * 45)}s` : 'STANDBY'}</span>
              </div>
              <div className="w-full h-2 bg-cyan-950/50 rounded-full overflow-hidden border border-cyan-900/60 p-[1px]">
                <div 
                  className={`h-full rounded-full transition-all duration-100 ${
                    stats.comboCount >= 3 ? 'bg-gradient-to-r from-cyan-400 to-purple-500' : 'bg-cyan-500'
                  }`}
                  style={{ width: `${comboTimeLeftFraction * 100}%` }}
                />
              </div>
            </div>
          </div>

        </section>

        {/* FLOATING XP NOTIFICATION (TOAST) */}
        <AnimatePresence>
          {xpAddedToast && (
            <motion.div
              initial={{ opacity: 0, y: 10, scale: 0.9 }}
              animate={{ opacity: 1, y: -20, scale: 1.05 }}
              exit={{ opacity: 0, scale: 0.9, y: -30 }}
              transition={{ duration: 0.35 }}
              onAnimationComplete={() => {
                setTimeout(() => setXpAddedToast(null), 1500);
              }}
              className="fixed bottom-10 left-1/2 transform -translate-x-1/2 z-50 bg-gradient-to-r from-purple-950 to-cyan-950 border border-cyan-500 px-6 py-3 rounded-full text-glow-cyan font-orbitron font-bold text-center glow-cyan shadow-xl pointer-events-none flex items-center gap-3"
            >
              <span>✨</span>
              <span>XP RECEIVED: +{xpAddedToast.xp}</span>
              {xpAddedToast.multiplier > 1 && (
                <span className="text-xs bg-cyan-500 text-slate-950 px-2 py-0.5 rounded-full font-bold">
                  MULTI x{xpAddedToast.multiplier}
                </span>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {/* WORKSPACE AREA */}
        <main className="w-full max-w-5xl px-4 sm:px-6 mt-8 grid grid-cols-1 lg:grid-cols-3 gap-6 z-10 items-start">
          
          {/* COLUMN 1 & 2: QUEST ADD & LISTING */}
          <div className="lg:col-span-2 flex flex-col gap-6 w-full">
            
            {/* ADD QUEST BUILDER */}
            <div id="add_quest_panel" className="bg-slate-900/40 border border-purple-900/30 rounded-2xl p-5 glow-purple backdrop-blur-md">
              <h2 className="font-orbitron font-bold text-lg text-purple-300 tracking-wide flex items-center gap-2 mb-4">
                🛡️ LOG_NEW_QUEST
              </h2>
              
              <form onSubmit={handleAddTask} className="flex flex-col gap-4">
                <div className="flex flex-col sm:flex-row gap-3">
                  <input
                    type="text"
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    placeholder="Describe adventure or objective..."
                    className="flex-1 bg-slate-950 border border-purple-900/50 hover:border-purple-700 focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 rounded-xl px-4 py-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none transition font-sans font-medium"
                    maxLength={100}
                    id="quest_text_input"
                  />
                  <button
                    type="submit"
                    disabled={!inputText.trim()}
                    className={`px-6 py-3 font-orbitron font-extrabold rounded-xl text-sm tracking-wider uppercase shadow-md transition-all active:scale-[0.98] ${
                      inputText.trim() 
                        ? 'bg-gradient-to-r from-purple-500 to-cyan-500 text-slate-950 hover:shadow-[0_0_20px_rgba(34,211,238,0.4)] hover:brightness-110 cursor-pointer font-black' 
                        : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700/50'
                    }`}
                  >
                    DEPLOY Quest
                  </button>
                </div>

                {/* ADVANCED SELECTIONS: DIFFICULTY & CATEGORY EXTRAS */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-purple-950/60">
                  
                  {/* CATEGORY SELECTOR */}
                  <div>
                    <label className="font-mono text-[10px] text-purple-400 uppercase tracking-widest block mb-2">Quest Realm Category</label>
                    <div className="grid grid-cols-3 gap-2">
                      {(['quest', 'daily', 'boss'] as const).map((cat) => (
                        <button
                          key={cat}
                          type="button"
                          onClick={() => setInputCategory(cat)}
                          className={`py-2 rounded-lg border font-mono text-xs uppercase flex flex-col items-center justify-center gap-1 transition cursor-pointer ${
                            inputCategory === cat
                              ? 'border-purple-400 bg-purple-950/60 text-purple-100 shadow-[0_0_8px_rgba(168,85,247,0.3)]'
                              : 'border-slate-800 bg-slate-950 text-slate-500 hover:border-slate-700 hover:text-slate-400'
                          }`}
                        >
                          <span className="text-base">{getCategoryEmoji(cat)}</span>
                          <span className="text-[10px]">{cat}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* DIFFICULTY SELECTOR */}
                  <div>
                    <label className="font-mono text-[10px] text-cyan-400 uppercase tracking-widest block mb-2">Challenge Tier (Base XP)</label>
                    <div className="grid grid-cols-3 gap-2">
                      {(['easy', 'medium', 'hard'] as const).map((diff) => {
                        const labelText = diff === 'easy' ? 'EASY (10xp)' : diff === 'medium' ? 'MED (20xp)' : 'HARD (40xp)';
                        return (
                          <button
                            key={diff}
                            type="button"
                            onClick={() => setInputDifficulty(diff)}
                            className={`py-2 px-1 rounded-lg border font-mono text-[9px] uppercase tracking-tight flex flex-col items-center justify-center transition cursor-pointer ${
                              inputDifficulty === diff
                                ? 'border-cyan-400 bg-cyan-950/60 text-cyan-100 shadow-[0_0_8px_rgba(6,182,212,0.3)]'
                                : 'border-slate-800 bg-slate-950 text-slate-500 hover:border-slate-700 hover:text-slate-400'
                            }`}
                          >
                            <span>⚡</span>
                            <span>{labelText}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                </div>
              </form>
            </div>

            {/* QUESTS FILTERS AND LISTING */}
            <div className="flex flex-col gap-4">
              
              {/* FILTERS */}
              <div className="flex overflow-x-auto gap-2 pb-1 scrollbar-thin scrollbar-thumb-purple-900 scrollbar-track-transparent">
                {(['all', 'quest', 'daily', 'boss', 'completed'] as const).map((filter) => (
                  <button
                    key={filter}
                    onClick={() => setActiveFilter(filter)}
                    className={`px-4 py-2 font-orbitron font-medium text-[11px] rounded-full uppercase tracking-wider transition whitespace-nowrap cursor-pointer ${
                      activeFilter === filter
                        ? 'bg-purple-600 text-white shadow-[0_0_12px_rgba(168,85,247,0.5)] border border-purple-400'
                        : 'bg-slate-900/80 text-slate-400 border border-slate-800/80 hover:text-slate-200 hover:border-purple-900/60'
                    }`}
                  >
                    {filter === 'all' && '🌍 All Objectives'}
                    {filter === 'quest' && '🛡️ Normal Quests'}
                    {filter === 'daily' && '📅 Daily Bounties'}
                    {filter === 'boss' && '💀 Boss raids'}
                    {filter === 'completed' && '🏆 Achievements Logified'}
                  </button>
                ))}
              </div>

              {/* DYNAMIC QUEST LIST CARD CONTAINER */}
              <div id="quest_cards_root" className="flex flex-col gap-3 min-h-[300px]">
                <AnimatePresence mode="popLayout">
                  {filteredTasks.length === 0 ? (
                    <motion.div
                      layout
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="flex flex-col items-center justify-center p-12 bg-slate-900/20 border border-dashed border-slate-800 rounded-2xl text-center"
                    >
                      <span className="text-4xl mb-3">📭</span>
                      <p className="font-orbitron text-slate-500 font-bold uppercase text-xs tracking-wider">
                        Aura level secure. No actions required.
                      </p>
                      <p className="text-slate-600 text-xs mt-1">
                        Select tags or initiate a Quest configuration above.
                      </p>
                    </motion.div>
                  ) : (
                    filteredTasks.map((task) => (
                      <motion.div
                        key={task.id}
                        layout
                        initial={{ opacity: 0, x: -30, scale: 0.95 }}
                        animate={{ opacity: 1, x: 0, scale: 1 }}
                        exit={{ 
                          opacity: 0, 
                          x: 100, 
                          scale: 0.9,
                          transition: { duration: 0.35, ease: 'easeIn' }
                        }}
                        className={`group relative overflow-hidden bg-slate-900/50 border rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 transition duration-300 ${
                          task.completed 
                            ? 'border-emerald-950/60 bg-emerald-950/10' 
                            : 'border-slate-800 hover:border-purple-900/50 hover:bg-slate-900/85'
                        }`}
                        id={`task_card_${task.id}`}
                      >
                        {/* Interactive Sparkle background on completion */}
                        {task.completed && (
                          <div className="absolute inset-0 bg-gradient-to-r from-emerald-500/5 to-transparent pointer-events-none" />
                        )}

                        <div className="flex items-start gap-3.5 flex-1 min-w-0">
                          {/* CHECKBOX GRIP */}
                          <button
                            type="button"
                            onClick={() => handleToggleTask(task.id)}
                            className={`w-6 h-6 rounded-lg border-2 flex items-center justify-center flex-shrink-0 transition-transform active:scale-95 cursor-pointer ${
                              task.completed
                                ? 'border-emerald-400 bg-emerald-950 text-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.3)]'
                                : 'border-purple-600 bg-slate-950 text-transparent hover:border-cyan-400'
                            }`}
                          >
                            {task.completed ? '✓' : ''}
                          </button>

                          <div className="min-w-0 flex-1">
                            {/* TEXT DESCRIPTION */}
                            <p className={`text-sm font-medium leading-relaxed break-words ${
                              task.completed 
                                ? 'text-slate-500 line-through' 
                                : 'text-slate-100 group-hover:text-purple-200'
                            }`}>
                              {task.text}
                            </p>

                            {/* LABELS METRICS FOOTER */}
                            <div className="flex flex-wrap gap-2 mt-2 items-center font-mono text-[9px] uppercase tracking-wider">
                              <span className="flex items-center gap-1 text-slate-500">
                                {getCategoryEmoji(task.category)} {task.category}
                              </span>
                              
                              <span className={`px-2 py-0.5 rounded border ${getDifficultyColor(task.difficulty)}`}>
                                {task.difficulty}
                              </span>

                              {task.dueDate && (
                                <span className="text-purple-400 bg-purple-950/30 border border-purple-900/30 px-1.5 py-0.5 rounded">
                                  ⏳ {task.dueDate}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* DELETE ARMORY OPTION */}
                        <div className="flex sm:self-center self-end items-center gap-1 flex-shrink-0">
                          <button
                            onClick={() => handleDeleteTask(task.id)}
                            className="p-1.5 rounded-lg border border-transparent text-slate-500 hover:text-rose-400 hover:border-rose-950 hover:bg-rose-950/20 transition cursor-pointer"
                            title="Abort Quest"
                          >
                            🗑️
                          </button>
                        </div>
                      </motion.div>
                    ))
                  )}
                </AnimatePresence>
              </div>

            </div>

          </div>

          {/* COLUMN 3: ARMORY OF ACHIVEMENTS (BADGES) */}
          <div className="w-full flex flex-col gap-6">
            
            {/* INSTRUCTIONAL TIP CARD */}
            <div className="bg-slate-900/40 border border-cyan-900/30 rounded-2xl p-4 glow-cyan">
              <h3 className="font-orbitron font-semibold text-xs text-cyan-300 uppercase tracking-widest flex items-center gap-2 mb-2">
                🎮 GAME_PLAYBOOK
              </h3>
              <p className="text-xs text-slate-400 leading-normal font-sans">
                Complete quests consecutively within <strong className="text-cyan-300">45 seconds</strong> of each sibling completion to increase your speed multipliers up to <strong className="text-purple-400">2.0x</strong>. Level up with every 100 XP acquired!
              </p>
            </div>

            {/* UNLOCKED ACHIVEMENTS GRIP */}
            <div id="armory_section" className="bg-slate-900/40 border border-purple-900/30 rounded-2xl p-5 glow-purple">
              <h2 className="font-orbitron font-bold text-sm text-purple-300 tracking-wide uppercase mb-4 flex items-center justify-between">
                <span>🏆 Achievements Armory</span>
                <span className="font-mono text-[10px] text-cyan-400 lowercase italic bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-900/40">
                  {stats.unlockedBadgeIds.length} / {BADGES.length} unlocked
                </span>
              </h2>

              <div className="flex flex-col gap-3.5">
                {BADGES.map((badge) => {
                  const isUnlocked = stats.unlockedBadgeIds.includes(badge.id);
                  return (
                    <div 
                      key={badge.id}
                      className={`flex gap-3 p-3 rounded-xl border transition duration-300 ${
                        isUnlocked 
                          ? 'bg-gradient-to-r from-purple-950/50 to-slate-900 border-purple-500/40 shadow-[0_0_10px_rgba(168,85,247,0.15)]' 
                          : 'bg-slate-950/30 border-slate-900 opacity-40 hover:opacity-60'
                      }`}
                    >
                      {/* Badge Badge/Emoji */}
                      <div className={`w-11 h-11 rounded-lg border-2 flex items-center justify-center text-xl flex-shrink-0 ${
                        isUnlocked 
                          ? 'bg-purple-950 border-purple-400 text-glow-purple shadow-[0_0_8px_rgba(168,85,247,0.4)]' 
                          : 'bg-slate-950 border-slate-800'
                      }`}>
                        {badge.icon}
                      </div>

                      {/* Content */}
                      <div className="min-w-0 flex-1">
                        <h4 className={`text-xs font-semibold tracking-wide flex items-center justify-between ${
                          isUnlocked ? 'text-purple-300' : 'text-slate-500'
                        }`}>
                          <span>{badge.title}</span>
                          {isUnlocked && (
                            <span className="font-mono text-[8px] bg-emerald-950 text-emerald-400 px-1.5 py-0.5 rounded lowercase uppercase-none">
                              CLAIMED
                            </span>
                          )}
                        </h4>
                        <p className="text-[10px] text-slate-400 mt-1 leading-normal">
                          {badge.description}
                        </p>
                      </div>

                    </div>
                  );
                })}
              </div>

            </div>

          </div>

        </main>

        {/* RECENTLY UNLOCKED BADGES (SLIDEOUT NOTIFICATION LAYER) */}
        <div id="unlocks_notification_overlay" className="fixed bottom-6 right-6 z-50 flex flex-col gap-3 pointer-events-none max-w-sm w-full font-sans">
          <AnimatePresence>
            {recentlyUnlockedBadges.map((badge) => (
              <motion.div
                key={`recent_${badge.id}`}
                initial={{ opacity: 0, x: 100, y: 10 }}
                animate={{ opacity: 1, x: 0, y: 0 }}
                exit={{ opacity: 0, x: 50, scale: 0.9 }}
                transition={{ type: 'spring', damping: 15 }}
                className="bg-slate-900 border-2 border-emerald-500 p-4 rounded-xl shadow-[0_0_20px_rgba(16,185,129,0.3)] pointer-events-auto flex gap-4"
              >
                <div className="w-12 h-12 rounded-lg bg-emerald-950 border-2 border-emerald-400 flex items-center justify-center text-2xl flex-shrink-0">
                  {badge.icon}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-orbitron font-extrabold text-xs text-emerald-400 tracking-wider">ACHIEVEMENT UNLOCKED!</span>
                    <button 
                      onClick={() => setRecentlyUnlockedBadges(prev => prev.filter(b => b.id !== badge.id))}
                      className="text-slate-500 hover:text-slate-200 cursor-pointer text-xs"
                    >
                      ✕
                    </button>
                  </div>
                  <h4 className="text-slate-200 text-sm font-semibold mt-0.5">{badge.title}</h4>
                  <p className="text-slate-400 text-xs mt-0.5">{badge.description}</p>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* STUNNING CELEBRATION MODAL OVERLAY */}
        <AnimatePresence>
          {showLevelUp && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4"
            >
              <div className="absolute inset-0 z-0 pointer-events-none opacity-30 overflow-hidden">
                <div className="w-[200%] h-[200%] absolute top-[-50%] left-[-50%] bg-[radial-gradient(ellipse_at_center,rgba(147,51,234,0.3)_0%,transparent_70%)] animate-pulse" />
              </div>

              <motion.div
                initial={{ scale: 0.8, y: 50, opacity: 0 }}
                animate={{ scale: 1, y: 0, opacity: 1 }}
                exit={{ scale: 0.8, y: 50, opacity: 0 }}
                transition={{ type: 'spring', damping: 15 }}
                className="bg-gradient-to-b from-slate-900 to-slate-950 border-2 border-purple-500/80 max-w-md w-full rounded-2xl p-6 glow-purple relative z-10 text-center"
              >
                {/* Visual Party burst */}
                <div className="text-5xl animate-bounce mb-3">🔮🔊⚡</div>
                
                <h2 className="font-orbitron font-black text-3xl tracking-widest text-glow-purple text-purple-300 uppercase">
                  CLASS UPGRADED!
                </h2>
                
                <p className="font-mono text-xs text-cyan-400 uppercase tracking-widest mt-1">
                  You have achieved Level {stats.level}!
                </p>

                <div className="my-6 py-4 bg-slate-950/60 border border-purple-950 rounded-xl max-w-sm mx-auto flex flex-col gap-3">
                  <div className="flex justify-between px-6 font-mono text-xs text-slate-400">
                    <span>OLD CLASS SECTOR:</span>
                    <span className="text-slate-300">Level {levelUpFrom}</span>
                  </div>
                  <div className="flex justify-between px-6 font-mono text-xs text-purple-400">
                    <span>NEW SECTOR POWER:</span>
                    <strong className="text-glow-purple">Level {stats.level}</strong>
                  </div>
                  <div className="flex justify-between px-6 font-mono text-xs text-cyan-400">
                    <span>RANK CONFERRED:</span>
                    <strong className="text-glow-cyan text-xs">{currentRank}</strong>
                  </div>
                </div>

                <p className="text-slate-400 text-xs mb-6 px-4">
                  Your quest discipline expands your influence. Keep up the flawless streak to claim total dominion!
                </p>

                <button
                  type="button"
                  onClick={() => setShowLevelUp(false)}
                  className="w-full py-3 bg-gradient-to-r from-purple-500 to-cyan-500 text-slate-950 font-orbitron font-black rounded-xl text-xs tracking-widest uppercase hover:shadow-[0_0_20px_rgba(168,85,247,0.5)] transition cursor-pointer"
                >
                  RESUME MY GRIND ⚔️
                </button>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </div>
  );
}
