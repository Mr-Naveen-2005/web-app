export interface Task {
  id: string;
  text: string;
  difficulty: 'easy' | 'medium' | 'hard';
  completed: boolean;
  createdAt: string;
  completedAt: string | null;
  category: 'quest' | 'daily' | 'boss';
}

export interface Badge {
  id: string;
  title: string;
  description: string;
  icon: string;
  conditionType: 'tasks_completed' | 'level_reached' | 'streak_reached' | 'combo_reached';
  conditionValue: number;
}

export interface GameStats {
  xp: number;
  level: number;
  streak: number;
  lastCompletedDate: string | null; // YYYY-MM-DD
  comboCount: number;
  lastCompletedTime: number | null; // timestamp in ms
  totalTasksCompleted: number;
  unlockedBadgeIds: string[];
}
